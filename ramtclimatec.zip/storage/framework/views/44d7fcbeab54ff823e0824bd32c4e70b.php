<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="space-y-6">

        
        <div class="flex flex-wrap gap-3">
            <span style="background:#fee2e2;color:#b91c1c;padding:4px 12px;border-radius:999px;font-size:12px;font-weight:600;">● Vencida</span>
            <span style="background:#ffedd5;color:#c2410c;padding:4px 12px;border-radius:999px;font-size:12px;font-weight:600;">● Menos de 15 días</span>
            <span style="background:#fef9c3;color:#a16207;padding:4px 12px;border-radius:999px;font-size:12px;font-weight:600;">● Menos de 30 días</span>
            <span style="background:#dcfce7;color:#15803d;padding:4px 12px;border-radius:999px;font-size:12px;font-weight:600;">● Al día</span>
        </div>

        
        <?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <div class="overflow-x-auto">
                <table class="w-full text-sm text-left divide-y divide-gray-200 dark:divide-white/5">
                    <thead>
                        <tr class="text-xs uppercase text-gray-500 dark:text-gray-400">
                            <th class="px-4 py-3 font-medium">Equipo</th>
                            <th class="px-4 py-3 font-medium">Ubicación</th>
                            <th class="px-4 py-3 font-medium">Cliente</th>
                            <th class="px-4 py-3 font-medium">Próxima Mantención</th>
                            <th class="px-4 py-3 font-medium">Días restantes</th>
                            <th class="px-4 py-3 font-medium">Estado</th>
                            <th class="px-4 py-3 font-medium">Acción</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200 dark:divide-white/5">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $this->getClientes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $badgeStyle = match($cliente->alerta) {
                                    'vencida' => 'background:#fee2e2;color:#b91c1c;',
                                    'urgente' => 'background:#ffedd5;color:#c2410c;',
                                    'proximo' => 'background:#fef9c3;color:#a16207;',
                                    default   => 'background:#dcfce7;color:#15803d;',
                                };

                                $label = match($cliente->alerta) {
                                    'vencida' => '● Vencida',
                                    'urgente' => '● Urgente',
                                    'proximo' => '● Próximo',
                                    default   => '● Al día',
                                };

                                $dias = $cliente->dias_restantes;

                                $diasTexto = $dias < 0
                                    ? abs($dias) . ' días atrás'
                                    : ($dias === 0 ? 'Hoy' : $dias . ' días');
                            ?>

                            <tr class="text-gray-900 dark:text-gray-100">
                                <td class="px-4 py-3 font-semibold">
                                    <?php echo e($cliente->equipo_info); ?>

                                </td>

                                <td class="px-4 py-3">
                                    <?php echo e($cliente->ubicacion ?? '—'); ?>

                                </td>

                                <td class="px-4 py-3">
                                    <?php echo e($cliente->cliente_nombre); ?>

                                </td>

                                <td class="px-4 py-3">
                                    <?php echo e(\Carbon\Carbon::parse($cliente->proxima_mantencion)->format('d/m/Y')); ?>

                                </td>

                                <td class="px-4 py-3 font-medium">
                                    <?php echo e($diasTexto); ?>

                                </td>

                                <td class="px-4 py-3">
                                    <span style="<?php echo e($badgeStyle); ?>padding:4px 10px;border-radius:999px;font-size:12px;font-weight:600;">
                                        <?php echo e($label); ?>

                                    </span>
                                </td>

                                <td class="px-4 py-3">
                                    <a href="<?php echo e(route('filament.admin.resources.orden-trabajos.create', [
                                        'cliente_id' => $cliente->cliente_id,
                                        'direccion_id' => $cliente->direccion_id,
                                    ])); ?>"
                                    style="background:#16a34a;color:#fff;padding:5px 12px;border-radius:6px;font-size:12px;font-weight:600;text-decoration:none;">
                                        + Crear OT
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="px-4 py-8 text-center text-gray-400 dark:text-gray-500">
                                    No hay equipos con mantención programada.
                                </td>
                            </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\ramtclimatec\resources\views/filament/pages/proximas-mantenciones-page.blade.php ENDPATH**/ ?>