<?php

namespace App\Exports;

use App\Models\Equipo;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;

class EquiposPorClienteExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize
{
    protected $clienteId;

    public function __construct($clienteId)
    {
        $this->clienteId = $clienteId;
    }

    public function collection()
    {
        return Equipo::where('cliente_id', $this->clienteId)->get();
    }

    public function headings(): array
    {
        return [
            'Ubicación',
            'Marca',
            'Modelo',
            'BTU',
            'Refrigerante',
            'Última Mantención',
            'Próxima Mantención',
            'Activo'
        ];
    }

    public function map($equipo): array
    {
        return [
            $equipo->ubicacion,
            $equipo->marca,
            $equipo->modelo,
            $equipo->capacidad_enfriamiento_btu ?? $equipo->capacidad_calefaccion_btu ?? 'N/A',
            $equipo->tipo_refrigerante,
            $equipo->ultima_mantencion ? date('d/m/Y', strtotime($equipo->ultima_mantencion)) : 'No registrada',
            $equipo->proxima_mantencion ? date('d/m/Y', strtotime($equipo->proxima_mantencion)) : 'No registrada',
            $equipo->activo ? 'Sí' : 'No',
        ];
    }
}